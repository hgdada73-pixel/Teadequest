TradeQuest Web v3
=================
A mobile-first trading LEARNING GAME. It uses virtual money only.

What is new:
- Real-company themed campaign: Reliance Industries, Tata Motors, TCS, Infosys, HDFC Bank, ITC.
- Hidden-future-candle gameplay: only candles revealed so far are visible.
- Coach instructions before each decision.
- Virtual Buy / Wait / Exit.
- Virtual quantity, P&L, stop-loss and target.
- Automatic stop/target checks on newly revealed candles.
- Missions, XP, levels, coins, badges, streak and local save.
- No broker, no UPI, no real-money execution.

Important:
The company names are real, but the bundled price candles are fictionalized educational scenarios, not live prices or investment recommendations.
To use actual live market data later, connect a suitable market-data API/backend and keep the game in virtual mode.

Run:
1. Keep all 3 files in the same folder.
2. Open index.html in a browser.
3. On mobile, use browser "Add to Home screen" if desired.
