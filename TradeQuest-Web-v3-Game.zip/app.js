const companies=[
 {id:"RELIANCE",name:"Reliance Industries",ticker:"RELIANCE",sector:"Energy • Telecom • Retail",diff:"Beginner",lesson:"Trend + pullback"},
 {id:"TATAMOTORS",name:"Tata Motors",ticker:"TATAMOTORS",sector:"Automobile",diff:"Intermediate",lesson:"Breakout + risk"},
 {id:"TCS",name:"Tata Consultancy Services",ticker:"TCS",sector:"IT Services",diff:"Beginner",lesson:"Range + patience"},
 {id:"INFY",name:"Infosys",ticker:"INFY",sector:"IT Services",diff:"Intermediate",lesson:"Trend reversal"},
 {id:"HDFCBANK",name:"HDFC Bank",ticker:"HDFCBANK",sector:"Banking",diff:"Intermediate",lesson:"Support bounce"},
 {id:"ITC",name:"ITC",ticker:"ITC",sector:"FMCG • Hotels",diff:"Beginner",lesson:"Sideways market"}
];

const scenarioPatterns={
 RELIANCE:{base:2450,pattern:"pullback",dates:"Educational scenario"},
 TATAMOTORS:{base:760,pattern:"breakout",dates:"Educational scenario"},
 TCS:{base:3650,pattern:"range",dates:"Educational scenario"},
 INFY:{base:1500,pattern:"reversal",dates:"Educational scenario"},
 HDFCBANK:{base:1700,pattern:"support",dates:"Educational scenario"},
 ITC:{base:450,pattern:"sideways",dates:"Educational scenario"}
};

function makeCandles(base,pattern,seed){
 let r=mulberry32(seed), a=[], p=base;
 for(let i=0;i<34;i++){
   let drift=0;
   if(pattern==="pullback") drift=i<10?.006:i<16?-0.004:.007;
   if(pattern==="breakout") drift=i<12?.001:i<20?-0.002:.009;
   if(pattern==="range") drift=(i%8<4?.002:-.002);
   if(pattern==="reversal") drift=i<18?-.005:.008;
   if(pattern==="support") drift=i<14?-.002:i<20?.001:.006;
   if(pattern==="sideways") drift=(i%10<5?.0015:-.0015);
   let noise=(r()-.5)*.018;
   let o=p, c=p*(1+drift+noise);
   let h=Math.max(o,c)*(1+.004+r()*.008), l=Math.min(o,c)*(1-.004-r()*.008);
   a.push({o,h,l,c,date:"Day "+(i+1)});
   p=c;
 }
 return a;
}
function mulberry32(a){return function(){let t=a+=0x6D2B79F5;t=Math.imul(t^t>>>15,t|1);t^=t+Math.imul(t^t>>>7,t|61);return((t^t>>>14)>>>0)/4294967296}}

const lessons=[
 ["🎯","Trend","Higher highs + higher lows can indicate an uptrend. In the game, observe first—don't rush."],
 ["🕯️","Candles","Open, high, low and close tell the story of one market period."],
 ["🛡️","Risk Management","A virtual trade should have a predefined exit and a small amount at risk."],
 ["⚖️","Risk / Reward","Compare the possible loss with the possible gain before taking a virtual trade."],
 ["🚫","FOMO","A fast-moving candle is not automatically a signal. Waiting for confirmation is a skill."],
 ["🔎","Support & Resistance","Previous reaction zones can help you form a learning hypothesis, not a guarantee."]
];

const missions=[
 {id:"first",title:"First Decision",icon:"🎮",desc:"Complete one guided company scenario.",xp:150},
 {id:"risk",title:"Risk Manager",icon:"🛡️",desc:"Complete a trade with stop-loss and target set.",xp:200},
 {id:"patient",title:"No FOMO",icon:"🧘",desc:"Use WAIT at least once before your virtual entry.",xp:180},
 {id:"three",title:"Market Explorer",icon:"🌍",desc:"Play 3 different company scenarios.",xp:300}
];

let state=JSON.parse(localStorage.getItem("tq_v3_state")||"null")||{
 xp:0,coins:500,balance:100000,level:1,streak:0,done:0,best:0,companiesPlayed:[],badges:["rookie"],missionsDone:[],waitUsed:false
};
let game=null;

function save(){localStorage.setItem("tq_v3_state",JSON.stringify(state));renderGlobal()}
function xpNeeded(){return 500+(state.level-1)*250}
function addXP(n){state.xp+=n;while(state.xp>=xpNeeded()){state.xp-=xpNeeded();state.level++;state.coins+=100;toast("LEVEL UP! 🎉 Level "+state.level)}}
function renderGlobal(){
 document.querySelector("#levelBadge").textContent="LVL "+state.level;
 document.querySelector("#xpText").textContent=state.xp+" XP";
 document.querySelector("#coinText").textContent="🪙 "+state.coins;
 document.querySelector("#homeBalance").textContent=money(state.balance);
 document.querySelector("#streak").textContent=state.streak+" 🔥";
 let need=xpNeeded(),pct=Math.min(100,state.xp/need*100);
 document.querySelector("#profileLevel").textContent="Level "+state.level;
 document.querySelector("#profileXP").textContent=state.xp+" / "+need+" XP";
 document.querySelector("#progressPct").textContent=Math.round(pct)+"%";
 document.querySelector("#xpBar").style.width=pct+"%";
 document.querySelector("#scenariosDone").textContent=state.done;
 document.querySelector("#bestScore").textContent=state.best;
 document.querySelector("#badges").innerHTML=["rookie","risk","patient","explorer"].map(b=>{
   let names={rookie:"🎮 Rookie",risk:"🛡️ Risk Manager",patient:"🧘 Patient Trader",explorer:"🌍 Explorer"};
   return `<div class="badge ${state.badges.includes(b)?"":"locked"}">${names[b]}</div>`
 }).join("");
}
function money(n){return "₹"+Math.round(n).toLocaleString("en-IN")}
function showScreen(id){
 document.querySelectorAll(".screen").forEach(x=>x.classList.remove("active"));
 document.querySelector("#"+id).classList.add("active");
 document.querySelectorAll(".bottomnav button").forEach(x=>x.classList.toggle("active",x.dataset.screen===id));
 if(id==="markets")renderCompanies();
 if(id==="missions")renderMissions();
 if(id==="learn")renderLessons();
 if(id==="profile")renderGlobal();
 window.scrollTo(0,0);
}
function renderCompanies(){
 document.querySelector("#companyGrid").innerHTML=companies.map(c=>`
 <div class="company card">
   <span class="ticker">${c.ticker} • ${c.diff}</span><h2>${c.name}</h2>
   <p>${c.sector}<br>Lesson: ${c.lesson}</p>
   <button class="primary" onclick="startScenario('${c.id}')">▶ Play Scenario</button>
 </div>`).join("");
}
function renderMissions(){
 document.querySelector("#missionList").innerHTML=missions.map(m=>{
   let done=state.missionsDone.includes(m.id);
   return `<div class="mission card"><div class="missionIcon">${m.icon}</div><div><b>${m.title}</b><p>${m.desc}</p><span class="pill">+${m.xp} XP</span></div>${done?'<span class="pill">✓ Done</span>':'<button class="secondary" onclick="showScreen(\'markets\')">Play</button>'}</div>`
 }).join("");
}
function renderLessons(){
 document.querySelector("#lessonList").innerHTML=lessons.map((l,i)=>`
 <div class="lesson card"><div class="missionIcon">${l[0]}</div><div><b>Lesson ${i+1}: ${l[1]}</b><p>${l[2]}</p></div></div>`).join("");
}

function startScenario(id){
 const c=companies.find(x=>x.id===id), sc=scenarioPatterns[id];
 game={company:c,candles:makeCandles(sc.base,sc.pattern, id.length*173+state.done*31),idx:7,entry:null,qty:0,sl:null,tp:null,score:100,waits:0,opened:false,closed:false,ended:false,realized:0,missionRisk:false};
 if(!state.companiesPlayed.includes(id))state.companiesPlayed.push(id);
 renderTrade();
 showScreen("trade");
}
function current(){return game.candles[game.idx]}
function renderTrade(){
 if(!game)return;
 let c=current(), price=c.c;
 let pnl=game.entry?((price-game.entry)*game.qty):0;
 let risk=game.entry&&game.sl?Math.max(0,(game.entry-game.sl)*game.qty):0;
 let reward=game.entry&&game.tp?Math.max(0,(game.tp-game.entry)*game.qty):0;
 let rr=risk>0?(reward/risk).toFixed(1):"—";
 document.querySelector("#tradeView").innerHTML=`
 <div class="tradeHead"><div><button class="back" onclick="showScreen('markets')">← Market</button><span class="marketStatus"> • VIRTUAL MARKET</span><h1>${game.company.name}</h1><small>${game.company.sector} • ${game.company.lesson}</small></div><div class="pill">Candle ${game.idx+1}/${game.candles.length}</div></div>
 <div class="card coach"><strong>🧑‍🏫 Coach says</strong><p>${coachText()}</p></div>
 <div class="chartWrap"><canvas id="chart" class="chart"></canvas></div>
 <div class="card"><div class="sectionhead"><h2>${money(price)}</h2><span class="pill">${c.date}</span></div>
   <div class="position" style="margin-top:10px">
    <div class="mini"><small>Position</small><b>${game.entry?game.qty+" shares":"None"}</b></div>
    <div class="mini"><small>Entry</small><b>${game.entry?money(game.entry):"—"}</b></div>
    <div class="mini"><small>Virtual P&L</small><b>${game.entry?money(pnl):"—"}</b></div>
    <div class="mini"><small>R:R</small><b>${rr}</b></div>
   </div>
 </div>
 <div class="card controls">
   <label>Stop-loss<input id="sl" type="number" step="0.01" value="${game.sl||""}" placeholder="e.g. ${Math.round(price*.98)}"></label>
   <label>Target<input id="tp" type="number" step="0.01" value="${game.tp||""}" placeholder="e.g. ${Math.round(price*1.04)}"></label>
 </div>
 <div class="decision">
   <button class="action buy" ${game.entry||game.ended?"disabled":""} onclick="virtualBuy()">🟢 VIRTUAL BUY</button>
   <button class="action wait" ${game.ended?"disabled":""} onclick="waitAction()">⏸ WAIT</button>
   <button class="action exit" ${!game.entry||game.ended?"disabled":""} onclick="virtualExit('manual')">🔴 EXIT</button>
 </div>
 <div style="height:10px"></div>
 <button class="next" ${game.ended?"disabled":""} onclick="nextCandle()">Reveal Next Candle →</button>
 <div class="card"><div class="sectionhead"><b>Mission</b><span>${game.idx-6}/27 candles explored</span></div><div class="missionBar"><i style="width:${Math.min(100,(game.idx-6)/27*100)}%"></i></div></div>`;
 drawChart();
}
function coachText(){
 if(game.ended)return "Scenario complete. Review your score and the lesson before starting another company.";
 if(!game.entry){
   if(game.idx<12)return "First identify the direction. Are recent closes generally rising, falling or moving sideways? Don't trade just because one candle looks exciting.";
   return game.waits===0?"Look for confirmation. You can WAIT—good trading games reward patience too.":"Now compare your entry idea with a predefined stop-loss. Protecting downside is part of the lesson.";
 }
 let p=current().c;
 if(game.sl&&p<=game.sl)return "Your stop-loss zone has been reached. The game will protect the position automatically.";
 if(game.tp&&p>=game.tp)return "Your target zone has been reached. The game will check the target automatically.";
 return "Position open. Watch the next candle and ask: has the reason for my trade changed? Don't move the goalposts just because price moves.";
}
function getInputs(){let sl=parseFloat(document.querySelector("#sl")?.value),tp=parseFloat(document.querySelector("#tp")?.value);return {sl:isFinite(sl)?sl:null,tp:isFinite(tp)?tp:null}}
function virtualBuy(){
 if(!game||game.entry)return;
 let {sl,tp}=getInputs(), price=current().c;
 if(sl!==null && sl>=price){toast("Stop-loss entry se neeche hona chahiye.");return}
 if(tp!==null && tp<=price){toast("Target entry se upar hona chahiye.");return}
 game.entry=price;game.qty=Math.max(1,Math.floor(10000/price));game.sl=sl;game.tp=tp;game.opened=true;
 if(sl&&tp)game.missionRisk=true;
 addXP(25);toast("Virtual position opened 🎮");
 renderTrade();
}
function waitAction(){if(game.ended)return;game.waits++;state.waitUsed=true;game.score=Math.max(0,game.score-2);addXP(10);toast("Good. Patience is a skill.");save();renderTrade()}
function nextCandle(){
 if(game.ended)return;
 if(game.idx>=game.candles.length-1){finishScenario();return}
 game.idx++;
 let c=current();
 if(game.entry){
   if(game.sl && c.l<=game.sl){virtualExit("stop");return}
   if(game.tp && c.h>=game.tp){virtualExit("target");return}
   if(game.idx%5===0)addXP(10);
 }
 renderTrade();save();
}
function virtualExit(reason){
 if(!game.entry)return;
 let price=current().c;
 let pnl=(price-game.entry)*game.qty;
 game.realized=pnl;game.closed=true;game.entry=null;
 if(reason==="stop")game.score-=20;
 if(reason==="target")game.score+=35;
 toast(reason==="stop"?"Stop-loss triggered 🛡️":reason==="target"?"Target achieved 🎯":"Virtual position closed");
 if(game.idx>=game.candles.length-1)finishScenario();
 else renderTrade();
 save();
}
function finishScenario(){
 if(game.ended)return;
 if(game.entry){game.realized=(current().c-game.entry)*game.qty;game.entry=null}
 game.ended=true;state.done++;state.best=Math.max(state.best,Math.max(0,Math.round(game.score)));
 let earned=Math.max(50,Math.round(game.score))+game.realized>0?50:0;
 // deterministic reward: score-based + risk bonus
 earned=Math.max(50,Math.round(game.score));
 addXP(earned);
 if(game.missionRisk && !state.missionsDone.includes("risk")){state.missionsDone.push("risk");addXP(200);state.badges.push("risk")}
 if(game.waits>0 && !state.missionsDone.includes("patient")){state.missionsDone.push("patient");addXP(180);state.badges.push("patient")}
 if(!state.missionsDone.includes("first")){state.missionsDone.push("first");addXP(150)}
 if(state.companiesPlayed.length>=3&&!state.missionsDone.includes("three")){state.missionsDone.push("three");addXP(300);state.badges.push("explorer")}
 state.streak++;
 save();
 showResult();
}
function showResult(){
 let profit=game.realized, lesson=profit>=0?"Your virtual trade finished positive—but the important win is following a process.":"A losing virtual trade is useful if you learn from the decision. Review the entry, risk and exit.";
 let div=document.createElement("div");div.className="overlay";div.id="resultOverlay";
 div.innerHTML=`<div class="modal"><span class="eyebrow">SCENARIO COMPLETE</span><h2>${game.company.name}</h2><div class="score">${Math.max(0,Math.round(game.score))}</div><p>${lesson}</p><div class="grid2"><div class="mini"><small>Virtual P&L</small><b>${money(profit)}</b></div><div class="mini"><small>XP earned</small><b>+${Math.max(50,Math.round(game.score))}</b></div></div><p style="color:#8e9bb0">Coach lesson: ${game.missionRisk?"You used risk controls. Keep defining risk before entry.":"Next time, practice setting a stop-loss and target before opening a virtual position."}</p><button class="primary" style="width:100%" onclick="closeResult()">Continue Campaign</button></div>`;
 document.body.appendChild(div);
}
function closeResult(){document.querySelector("#resultOverlay")?.remove();showScreen("markets")}
function resetGame(){if(confirm("Reset all TradeQuest progress?")){localStorage.removeItem("tq_v3_state");location.reload()}}
function toast(s){let t=document.querySelector("#toast");t.textContent=s;t.classList.add("show");clearTimeout(window.__tt);window.__tt=setTimeout(()=>t.classList.remove("show"),1800)}

function drawChart(){
 const cv=document.querySelector("#chart");if(!cv)return;
 const dpr=devicePixelRatio||1,w=cv.clientWidth,h=cv.clientHeight;cv.width=w*dpr;cv.height=h*dpr;
 const ctx=cv.getContext("2d");ctx.scale(dpr,dpr);ctx.clearRect(0,0,w,h);
 const data=game.candles.slice(0,game.idx+1), pad={l:10,r:10,t:15,b:25};
 let vals=data.flatMap(x=>[x.h,x.l]);let min=Math.min(...vals),max=Math.max(...vals),range=max-min||1;
 const y=v=>pad.t+(max-v)/range*(h-pad.t-pad.b), gap=(w-pad.l-pad.r)/data.length, bw=Math.max(3,gap*.55);
 ctx.font="10px system-ui";ctx.fillStyle="#627087";
 for(let i=0;i<5;i++){let yy=pad.t+i*(h-pad.t-pad.b)/4;ctx.strokeStyle="#172335";ctx.beginPath();ctx.moveTo(0,yy);ctx.lineTo(w,yy);ctx.stroke();let val=max-(max-min)*i/4;ctx.fillText(Math.round(val).toLocaleString("en-IN"),8,yy-3)}
 data.forEach((x,i)=>{let xx=pad.l+i*gap+gap/2,yo=y(x.o),yc=y(x.c),yh=y(x.h),yl=y(x.l),up=x.c>=x.o;ctx.strokeStyle=up?"#35d6b0":"#ff7186";ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(xx,yh);ctx.lineTo(xx,yl);ctx.stroke();ctx.fillStyle=up?"#35d6b0":"#ff7186";let top=Math.min(yo,yc),bh=Math.max(2,Math.abs(yc-yo));ctx.fillRect(xx-bw/2,top,bw,bh)});
 if(game.entry){let yy=y(game.entry);ctx.strokeStyle="#ffd166";ctx.setLineDash([5,4]);ctx.beginPath();ctx.moveTo(0,yy);ctx.lineTo(w,yy);ctx.stroke();ctx.setLineDash([])}
 if(game.sl){let yy=y(game.sl);ctx.strokeStyle="#ff7186";ctx.setLineDash([4,4]);ctx.beginPath();ctx.moveTo(0,yy);ctx.lineTo(w,yy);ctx.stroke();ctx.setLineDash([])}
 if(game.tp){let yy=y(game.tp);ctx.strokeStyle="#35d6b0";ctx.setLineDash([4,4]);ctx.beginPath();ctx.moveTo(0,yy);ctx.lineTo(w,yy);ctx.stroke();ctx.setLineDash([])}
}

renderGlobal();showScreen("home");
window.addEventListener("resize",()=>{if(game)drawChart()});
